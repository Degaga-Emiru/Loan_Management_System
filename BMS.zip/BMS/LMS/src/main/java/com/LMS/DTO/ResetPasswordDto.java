package com.LMS.LMS.DTO;

public record ResetPasswordDto(String token, String newPassword) {}
